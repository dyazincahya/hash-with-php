
<img src="https://github.com/dyazincahya/hash-with-php/blob/master/favicon.png" data-canonical-src="https://github.com/dyazincahya/hash-with-php/blob/master/favicon.png" width="75" />

# HASH with PHP
Simple apps for hashing text with PHP, avaliable hash (MD5, SHA1, SHA224, SHA256, and SHA512). This apps use ```Indonesian Language```

### Screenshot
![](https://github.com/dyazincahya/hash-with-php/blob/master/hash-ss.png)

### Development by 
[kang-cahya.com](https://kang-cahya.com)

### License
[MIT License](https://github.com/dyazincahya/hash-with-php/blob/master/LICENSE)
